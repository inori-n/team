var mysql = require('mysql');
var connection = mysql.createConnection({
  host: '112.124.65.59',
  port: '3306',
  user: 'Waller_Shaun',
  password: '040426',
  database: 'waller_shaun'
});
module.exports = connection;