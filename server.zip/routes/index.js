var express = require('express');
var router = express.Router();

var connection = require('../db/sql.js')

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get("/prediction", function(req, res, next) {
    connection.query('select * from PondWaterMetrics Where ID < 3', function(error, results, fields) {
        if (error) throw error;
        // console.log('The solution is: ', results);
        res.send(results)
});

// router.get("/prediction", function(req, res, next) {
//     connection.query('select * from PondWaterMetrics Where ID < 3', function(error, results, fields) {
//         if (error) throw error;
//         // console.log('The solution is: ', results);
//         res.send(results)
// });

});

module.exports = router;
